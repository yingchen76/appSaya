<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Mahasiswa</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
					<form action="<?php echo e(url('/mahasiswa/new')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label>NIM</label>
							<input type="text" name="nim" class="form-control">
						</div>
						<div class="form-group">
							<label>Nama</label>
							<input type="text" name="nama" class="form-control">
						</div>
						<div class="form-group">
							<label>Prodi</label>
							<select name="prodi_id" class="form-control">
							  <option value="">Pilih Prodi</option>
							  <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <option value="<?php echo e($prodi->id); ?>"><?php echo e($prodi->nama); ?></option>
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\appSaya\resources\views/mahasiswa/create.blade.php */ ?>