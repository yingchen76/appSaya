<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Buat Mahasiswa Baru</div>
				<div class="card-body">
					<form action="<?php echo e(url('/mahasiswa/edit/' . $mahasiswa->id)); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label>NIM</label>
							<input type="text" name="nim" value="<?php echo e($mahasiswa->nim); ?>" class="form-control">
						</div>
						<div class="form-group">
							<label>Nama</label>
							<input type="text" name="nama" value="<?php echo e($mahasiswa->nama); ?>" class="form-control">
						</div>
						<div class="form-group">
							<label>Prodi</label>
							<select name="prodi_id" class="form-control">
							  <option value="">Pilih Prodi</option>
							  <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <option value="<?php echo e($prodi->id); ?>" <?php echo e(($mahasiswa->prodi_id == $prodi->id)?'selected':''); ?>><?php echo e($prodi->nama); ?></option>
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\appSaya\resources\views/mahasiswa/edit.blade.php */ ?>