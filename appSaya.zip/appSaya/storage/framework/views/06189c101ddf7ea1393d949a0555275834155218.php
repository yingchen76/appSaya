<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Kelas</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<a href="kelas/new" class="btn btn-primary">Buat Kelas</a>
<table class="table table-striped">
						<tr>
							<th>Nama Kelas</th>
							<th>Jenis Kelas</th>
							<th>Nama Guru</th>
							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($kelas->nama_kelas); ?></td>
							<td><?php echo e($kelas->jenis_kelas); ?></td>
							<td><?php echo e($kelas->user->name); ?></td>
							<td>
								<a href="/kelas/edit/<?php echo e($kelas->id); ?>">Edit</a>
								<a href="kelas/lihat/<?php echo e($kelas->id); ?>">View</a>
								<form action="/kelas/delete/<?php echo e($kelas->id); ?>" method="post">
									<?php echo e(csrf_field()); ?>

									<?php echo e(method_field('DELETE')); ?>

									<button type="submit" class="btn btn-danger btn-sm col-md-2">Hapus</button>
								</form>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\appSaya\resources\views/kelas/index.blade.php */ ?>