<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Kelas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
					<form action="<?php echo e(url('/kelas/new')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label>Nama Kelas</label>
							<input type="text" name="nama_kelas" class="form-control">
						</div>
						<div class="form-group">
							<label>Jenis Kelas</label><br>
							<input type="radio" name="jenis_kelas" value="private">&nbsp;&nbsp;Private Class&nbsp;&nbsp;
							<input type="radio" name="jenis_kelas" value="public"> &nbsp;&nbsp;Public Class&nbsp;&nbsp;
						</div>
						<div class="form-group">
							<label>Nama Guru</label>
							<input type="text" name="" value="<?php echo e(Auth::user()->name); ?>" class="form-control">
							<input type="hidden" name="user_id" class="form-control" value="<?php echo e(Auth::user()->id); ?>" readonly>
						</div>						
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\appSaya\resources\views/kelas/create.blade.php */ ?>