<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Ubah Kelas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
					<form action="<?php echo e(url('/kelas/edit/' . $kelas->id)); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label>Nama Kelas</label>
							<input type="text" name="nama_kelas" value="<?php echo e($kelas->nama_kelas); ?>" class="form-control">
						</div>
						<div class="form-group">
							<label>Jenis Kelas</label><br>
							<input type="radio" name="jenis_kelas" value="private"  <?php if(@$kelas->jenis_kelas == "private"): ?> checked <?php endif; ?>>&nbsp;&nbsp;Private Class&nbsp;&nbsp;
							<input type="radio" name="jenis_kelas" value="public" <?php if(@$kelas->jenis_kelas == "public"): ?> checked <?php endif; ?>> &nbsp;&nbsp;Public Class&nbsp;&nbsp;
						</div>
						
						<button type="submit" class="btn btn-primary">Simpan</button>
					</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\appSaya\resources\views/kelas/edit.blade.php */ ?>