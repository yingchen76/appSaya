<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Lihat</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
	<div>
		<a href="/tugas/index/<?php echo e($kelas->id); ?>" class="btn btn-primary">Tambah Tugas</a>
		<a href="/murid/index/<?php echo e($kelas->id); ?>" class="btn btn-success">Lihat siswa</a>
	</div>
	<form action="<?php echo e(url('/kelas/lihat/' . $kelas->id)); ?>" method="post">
	<?php echo e(csrf_field()); ?>

	<label>Nama Kelas</label>
		<p><?php echo e($kelas->nama_kelas); ?></p>
	<label>Jenis Kelas</label><br>
		<?php if(@$kelas->jenis_kelas == "private"): ?>
		    Private Class
		<?php endif; ?>
		<?php if(@$kelas->jenis_kelas == "public"): ?>
			Public Class
		<?php endif; ?>
	</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\appSaya\appSaya\resources\views/kelas/lihat.blade.php */ ?>