<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Kelas</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
	<div>
		<a href="/tugas/lihat/<?php echo e($kelas->id); ?>" class="btn btn-primary">Lihat Tugas</a>
	</div>
	<form action="<?php echo e(url('/tugas/new/'.$kelas->id)); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		<div>
			<label>Kelas</label>
			<input type="text" name="namakelas" value ="<?php echo e($kelas->nama_kelas); ?>" readonly>
			<input type="hidden" name="id_kelas" value="<?php echo e($kelas->id); ?>">
		</div>
		<div>
			<label>Nama Tugas</label>
			<input type="text" name="nama_tugas">
		</div>
		<div>
			<label>Deskripsi Tugas</label>
			<textarea name="deskripsi"> </textarea>
		</div>
		<div>
			<label>Deadline Tugas</label>
			<input type="date" name="deadline">
		</div>
		<button type="submit" class="btn btn-primary">Simpan</button>
		
		
	</form>
					
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\appSaya\appSaya\resources\views/tugas/index.blade.php */ ?>