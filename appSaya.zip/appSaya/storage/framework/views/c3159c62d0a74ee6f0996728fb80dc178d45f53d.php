<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Lihat</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
	<form action="<?php echo e(url('/tugas/lihat/' . $kelas->id)); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		<?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($kelas->id == $tugas->id_kelas): ?>
		<label>Nama Tugas</label>
		<p><?php echo e($tugas->nama_tugas); ?></p>
		<label>Deskripsi Tugas</label><br>
		<p><?php echo e($tugas->deskripsi); ?></p>
		<label>deadline</label>
		<p><?php echo e($tugas->deadline); ?></p>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\appSaya\appSaya\resources\views/tugas/lihat.blade.php */ ?>