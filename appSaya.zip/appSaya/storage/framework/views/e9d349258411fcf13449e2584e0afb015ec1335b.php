<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Prodi</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<a href="/prodi/new" class="btn btn-primary">Buat Prodi Baru</a>
<table class="table table-striped">

	<tr>
		<th>Kode</th>
		<th>Nama</th>
		<th>Action</th>
	</tr>
	<?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
   		<td><?php echo e($prodi->kode); ?></td>
		<td><?php echo e($prodi->nama); ?></td>
		<td>
			<a href="/prodi/edit/<?php echo e($prodi->id); ?>">Edit</a>
			<form action="/prodi/delete/<?php echo e($prodi->id); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field('DELETE')); ?>					
				<button type="submit" class="btn btn-danger btn-sm">Hapus</button>
			</form>
		</td>
	</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\appSaya\resources\views/prodi/index.blade.php */ ?>