<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
	<h1>Mahasiswa</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<a href="/mahasiswa/new" class="btn btn-primary">Buat Mahasiswa Baru</a>
<table class="table table-striped">
						<tr>
							<th>NIM</th>
							<th>Nama</th>
							<th>Prodi</th>
							<th>Action</th>
						</tr>
						<?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($mhs->nim); ?></td>
							<td><?php echo e($mhs->nama); ?></td>
							<td><?php echo e($mhs->prodi->nama); ?></td>
							<td>
								<a href="/mahasiswa/edit/<?php echo e($mhs->id); ?>">Edit</a>
								<from action="/mahasiswa/delete/<?php echo e($mhs->id); ?>" method="post">
									<?php echo e(csrf_field()); ?>

									<?php echo e(method_field('DELETE')); ?>

									<button type="submit" class="btn btn-danger btn-sm">Hapus</button>
								</from>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\appSaya\resources\views/mahasiswa/index.blade.php */ ?>