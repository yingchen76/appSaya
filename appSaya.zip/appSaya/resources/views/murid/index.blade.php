@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row justify-content-cinter">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">
					Kelas Saya
				</div>
				<div class="card-body">
					<table class="table table-stripped">
						<tr>
							<th>Kode Kelas</th>
							<th>Nama Kelas</th>
							<th>Pengajar</th>
						</tr>
						@foreach($murid as $murid)
						
						<tr>
							
							<td>{{$murid->kelas->id_kelas}}</td>
							<td>{{$murid->kelas->nama}}</td>
							
							
							
						</tr>
						@endforeach
						
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection