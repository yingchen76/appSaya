@extends('adminlte::page')

@section('title', 'AdminLTE')

@section('content_header')
	<h1>Lihat</h1>
@stop


@section('content')
	<form action="{{ url('/tugas/lihat/' . $kelas->id) }}" method="post">
		{{ csrf_field() }}
		@foreach ($tugas as $tugas)
		@if ($kelas->id == $tugas->id_kelas)
		<label>Nama Tugas</label>
		<p>{{$tugas->nama_tugas}}</p>
		<label>Deskripsi Tugas</label><br>
		<p>{{$tugas->deskripsi}}</p>
		<label>deadline</label>
		<p>{{$tugas->deadline}}</p>
		@endif
		@endforeach
	</form>


@stop