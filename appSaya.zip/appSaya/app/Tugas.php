<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tugas extends Model
{
    public $timestamps = false;
    public function tugas(){
    	return $this->belongsTo('App\Kelas');
    }
}
